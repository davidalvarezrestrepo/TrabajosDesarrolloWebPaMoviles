import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.tsx'
import CargarContactos from './CargarContactos';
import Loader from './Loader';
import ListaContactos from './ListaContactos';


function Contactos() {
  const { contactos, cargando } = CargarContactos();

  return (
    <>
      {cargando ? <Loader /> : <ListaContactos contactos={contactos} />}
    </>
  );
}


createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
    <Contactos />
  </StrictMode>,  
)


