interface Contacto {
  id: string;
  nombre: string;
  telefono: string;
}

interface Props {
  contactos: Contacto[];
}

function ListaContactos({ contactos }: Props) {
  return (
    <ul>
      {contactos.map((contacto) => (
        <li key={contacto.id}>
          {contacto.nombre} — {contacto.telefono}
        </li>
      ))}
    </ul>
  );
}

export default ListaContactos;