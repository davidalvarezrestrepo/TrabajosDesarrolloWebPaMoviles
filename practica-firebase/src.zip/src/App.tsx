import { IonContent, IonHeader, IonPage, IonTitle, IonToolbar } from '@ionic/react';
import useCargarTareas from './hooks/useCargarTareas';
import ListaTareas from './components/ListaTareas';

function Tareas() {
  const { tareas, setTareas, cargando } = useCargarTareas();

  function agregarTarea(titulo: string) {
    const nueva = { id: Date.now().toString(), titulo, completada: false };
    setTareas([...tareas, nueva]);
  }

  function completarTarea(id: string) {
    setTareas(
      tareas.map((t) => (t.id === id ? { ...t, completada: !t.completada } : t))
    );
  }

  function eliminarTarea(id: string) {
    setTareas(tareas.filter((t) => t.id !== id));
  }

  if (cargando) return <p>Cargando...</p>;

  return (
    <ListaTareas
      tareas={tareas}
      onAgregar={agregarTarea}
      onCompletar={completarTarea}
      onEliminar={eliminarTarea}
    />
  );
}

function App() {
  return (
    <IonPage>
      <IonHeader>
        <IonToolbar color="primary">
          <IonTitle>Gestor de Tareas</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent className="ion-padding">
        <Tareas />
      </IonContent>
    </IonPage>
  );
}

export default App;